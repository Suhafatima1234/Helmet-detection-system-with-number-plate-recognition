from flask import Flask, render_template, request, redirect, url_for, session
import os
from datetime import datetime
import numpy as np
import mysql.connector
import plotly.graph_objs as go
from collections import defaultdict



app = Flask(__name__, static_folder='static',static_url_path='/static')


UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
# base_directory = "F:/Project/proj2/static"

# Configure session to use a secret key
app.secret_key = 'your_secret_key_here'

# Define correct password
correct_password = "suha1234"

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="suha1234",
    database="project"
)

# @app.route('/')
# def index():
#     return render_template('main_page.html')


@app.route('/')
def index():
    return render_template('one.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'suha' and password == 'nish1234':  # Replace 'your_username' and 'your_password' with your actual credentials
            # Set session variable to indicate user is logged in
            session['logged_in'] = True
            return redirect(url_for('main_page'))
        else:
            error = "Wrong username or password. Please try again."
            return render_template('one.html', error=error)
    else:
        return render_template('one.html')

@app.route('/main_page')
def main_page():
    if 'logged_in' in session and session['logged_in']:
        return render_template('main_page.html')
    else:
        return redirect(url_for('login'))


@app.route('/dashboard')
def dashboard():
    if 'logged_in' in session and session['logged_in']:
        cursor = db.cursor()

        # Execute the SELECT query to fetch all rows from the table
        cursor.execute("SELECT * FROM numPlate")

        # Fetch all rows from the result
        rows = cursor.fetchall()

        decoded_rows = []
        for row in rows:
            row_list = list(row)
            relative_path = row_list[1]
            absolute_path = os.path.join(relative_path)
            row_list[1] = absolute_path.replace("\\", "/")  # Update the image path with forward slashes
            decoded_rows.append(tuple(row_list))
        # for row in rows:
        #     row_list = list(row)  # Convert tuple to list
        #     relative_path = row_list[1]  # Assuming the image path is at index 1

        #     # Concatenate the base directory with the relative path to form the absolute path
        #     absolute_path = os.path.join(base_directory, relative_path)

        #     row_list[1] = absolute_path  # Update the image path in the list

        #     decoded_rows.append(tuple(row_list))  # Convert the list back to a tuple and append to decoded_rows

        # Close the cursor
        cursor.close()

        # Pass the decoded rows to the HTML template for rendering
        return render_template('dashboard.html', rows=decoded_rows)
    else:
        return redirect(url_for('login'))

@app.route('/settings')
def settings():
    if 'logged_in' in session and session['logged_in']:
        return render_template('settings.html')
    else:
        return redirect(url_for('login'))

# @app.route('/history')
# def history():
#     if 'logged_in' in session and session['logged_in']:
#         # Logic for history page goes here
#         return render_template('history.html')
#     else:
#         return redirect(url_for('login'))

# @app.route('/themes')
# def themes():
#     if 'logged_in' in session and session['logged_in']:
#         # Logic for themes page goes here
#         return render_template('themes.html')
#     else:
#         return redirect(url_for('login'))

from flask import request

# @app.route('/graph')
# def graph():
#     if 'logged_in' in session and session['logged_in']:
#         cursor = db.cursor()
#         cursor.execute("SELECT * FROM numPlate")
#         rows = cursor.fetchall()
#         cursor.close()

#         # Count the number of pictures captured each day
#         day_count = defaultdict(int)
#         for row in rows:
#             timestamp = row[3]  # Assuming the fourth column contains the timestamp
#             date = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
#             day = date.strftime("%Y-%m-%d")  # Extract the day from the timestamp
#             day_count[day] += 1

#         # Extract x (days) and y (number of pictures) values for the graph
#         x = list(day_count.keys())
#         y = list(day_count.values())

#         graph_data = create_plotly_graph(x, y)
#         return render_template('graph.html', graph_data=graph_data)
#     else:
#         return redirect(url_for('login'))

# def create_plotly_graph(x, y):
#     trace = go.Bar(x=x, y=y, name='Number of Pictures Captured')
#     layout = go.Layout(title='Number of Pictures Captured by Day', xaxis=dict(title='Day'), yaxis=dict(title='Number of Pictures'))
#     graph_data = go.Figure(data=[trace], layout=layout)
#     return graph_data.to_html(full_html=False)



def get_graph_data(date=None):
    cursor = db.cursor()
    if date:
        cursor.execute("SELECT * FROM numPlate WHERE DATE(timestamp) = %s", (date,))
    else:
        cursor.execute("SELECT * FROM numPlate")
    rows = cursor.fetchall()
    cursor.close()

    # Count the number of pictures captured each day
    day_count = defaultdict(int)
    for row in rows:
        timestamp = row[3]
        date = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
        day = date.strftime("%Y-%m-%d")
        day_count[day] += 1

    # Extract x (days) and y (number of pictures) values for the graph
    x = list(day_count.keys())
    y = list(day_count.values())

    # Create Plotly graph data
    trace = go.Bar(x=x, y=y, name='Number of Pictures Captured')
    layout = go.Layout(title='Number of Pictures Captured by Day', xaxis=dict(title='Day'), yaxis=dict(title='Number of Pictures'))
    graph_data = go.Figure(data=[trace], layout=layout)

    return graph_data.to_json()

@app.route('/graph', methods=['GET', 'POST'])
def graph():
    if 'logged_in' in session and session['logged_in']:
        if request.method == 'POST':
            date = request.form['date']
            graph_data = get_graph_data(date=date)
        else:
            graph_data = get_graph_data()
        return render_template('graph.html', graph_data=graph_data)
    else:
        return redirect(url_for('login'))


# @app.route('/graph/daily', methods=['GET', 'POST'])
# def graph_daily():
#     if request.method == 'POST':
#         # Get data for the specified date
#         date = request.form['date']
#         graph_data = get_daily_graph_data(date)
#     else:
#         # Get data for the default date or month
#         graph_data = get_daily_graph_data()
    
#     return render_template('graph.html', graph_data=graph_data)

@app.route('/graph/monthly', methods=['GET', 'POST'])
def graph_monthly():
    if request.method == 'POST':
        # Get data for the specified month
        month = request.form['month']
        graph_data = get_monthly_graph_data(month)
    else:
        # Get data for the default month
        graph_data = get_monthly_graph_data()
    
    return render_template('graph.html', graph_data=graph_data)

# Function to get daily graph data
# def get_daily_graph_data(date=None):
#     cursor = db.cursor()
#     if date:
#         cursor.execute("SELECT * FROM your_table WHERE DATE(timestamp_column) = %s", (date,))
#     else:
#         cursor.execute("SELECT * FROM your_table")
    
#     rows = cursor.fetchall()
#     cursor.close()

#     day_count = defaultdict(int)
#     for row in rows:
#         timestamp = row[3]  # Assuming the fourth column contains the timestamp
#         day = timestamp.strftime("%Y-%m-%d")  # Extract the day from the timestamp
#         day_count[day] += 1

#     x = list(day_count.keys())
#     y = list(day_count.values())

#     trace = go.Bar(x=x, y=y, name='Number of Pictures Captured')
#     layout = go.Layout(title='Number of Pictures Captured by Day', xaxis=dict(title='Day'), yaxis=dict(title='Number of Pictures'))
#     graph_data = go.Figure(data=[trace], layout=layout)

#     return graph_data.to_json()

# Function to get monthly graph data
# Function to get monthly graph data
from datetime import datetime

def get_monthly_graph_data(month=None):
    cursor = db.cursor()
    if month:
        cursor.execute("SELECT * FROM numPlate WHERE DATE_FORMAT(timestamp, '%Y-%m') = %s", (month,))
    else:
        cursor.execute("SELECT * FROM numPlate")
    
    rows = cursor.fetchall()
    cursor.close()

    month_count = defaultdict(int)
    for row in rows:
        timestamp = row[3]  # Assuming the fourth column contains the timestamp
        if isinstance(timestamp, str):  # Check if timestamp is a string
            timestamp = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")  # Convert string to datetime object
        month = timestamp.strftime("%Y-%m")  # Extract the month from the timestamp
        month_count[month] += 1

    x = list(month_count.keys())
    y = list(month_count.values())

    trace = go.Bar(x=x, y=y, name='Number of Pictures Captured')
    layout = go.Layout(title='Number of Pictures Captured by Month', xaxis=dict(title='Month'), yaxis=dict(title='Number of Pictures'))
    graph_data = go.Figure(data=[trace], layout=layout)

    return graph_data.to_json()



if __name__ == '__main__':
    app.run(debug=True)
