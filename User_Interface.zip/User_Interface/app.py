from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

# Connect to the database
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="suha1234",
    database="project"
)

@app.route('/')
def index():
    return render_template('main.html')

@app.route('/check_fines', methods=['GET', 'POST'])
def check_fines():
    if request.method == 'POST':
        vehicle_number = request.form['vehicleNumber']
        print(vehicle_number)
        cursor = db.cursor()
        try:
            cursor.execute("SELECT plateno, status FROM numPlate WHERE plateno LIKE %s", ('%' + vehicle_number + '%',))
            fines = cursor.fetchall()
        except mysql.connector.Error as err:
            print("Error querying database:", err)
            fines = []
        finally:
            cursor.close()
        return render_template('fine.html', fines=fines)
    else:
        return render_template('fine.html')

@app.route('/pay_fine/<vehicle_number>', methods=['POST'])
def pay_fine(vehicle_number):
    return redirect(url_for('payment', vehicle_number=vehicle_number))

@app.route('/payment/<vehicle_number>', methods=['GET', 'POST'])
def payment(vehicle_number):
    if request.method == 'POST':
        # Process payment (not implemented in this example)
        # Update database to mark fine as paid
        cursor = db.cursor()
        try:
            print('%'+ vehicle_number+'%')
            cursor.execute("UPDATE numPlate SET status = 'paid' WHERE plateno like %s", ('%' + vehicle_number + '%',))
            db.commit()
            
        except mysql.connector.Error as err:
            print("Error updating database:", err)
            db.rollback()
        finally:
            cursor.close()
        # Redirect back to check_fines route to display the updated fines table
        return redirect(url_for('check_fines'))
        #return render_template('fines.html')
    else:
        return render_template('payment.html', vehicle_number=vehicle_number)

if __name__ == '__main__':
    app.run(debug=True,port=8282)
